/*
 * RELIC is an Efficient LIbrary for Cryptography
 * Copyright (C) 2007, 2008, 2009 RELIC Authors
 *
 * This file is part of RELIC. RELIC is legal property of its developers,
 * whose names are not listed here. Please refer to the COPYRIGHT file
 * for contact information.
 *
 * RELIC is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * RELIC is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with RELIC. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * @file
 *
 * Implementation of the R-Ate bilinear pairing.
 *
 * @version $Id: relic_pp_rate.c 214 2010-01-25 03:09:40Z dfaranha $
 * @ingroup pp
 */

#include "relic_core.h"
#include "relic_pp.h"
#include "relic_error.h"

/*============================================================================*/
/* Private definitions                                                        */
/*============================================================================*/

/**
 * Adds two prime elliptic curve points and evaluates the corresponding line
 * function at another elliptic curve point.
 * 
 * @param[out] l			- the result of the evaluation.
 * @param[in,out] r			- the first point to add, in Affine coordinates.
 * 							The result of the addition, in Jacobian coordinates.
 * @param[in] q				- the second point to add, in Jacobian coordinates.
 * @param[in] p				- the point where the line function will be
 * 							evaluated, in Affine coordinates.
 */
void rate_add(fp12_t l, ep2_t r, ep2_t q, ep_t p) {
	fp2_t slope;
	ep2_t t;

	fp2_null(slope);
	ep2_null(t);

	TRY {
		fp2_new(slope);
		ep2_new(t);

		ep2_copy(t, r);
		ep2_add_slp(r, slope, r, q);

		if (ep2_is_infty(r)) {
			fp12_zero(l);
			fp_set_dig(l[0][0][0], 1);
		} else {
			fp6_t n, d;

			fp6_new(d);
			fp6_new(n);

			fp_zero(d[0][1]);
			fp_copy(d[0][0], p->x);
			fp2_mul(d[0], d[0], slope);
			fp2_neg(d[0], d[0]);
			fp2_mul(d[2], r->z, q->y);
			fp2_mul(d[1], slope, q->x);
			fp2_sub(d[1], d[1], d[2]);
			fp2_zero(d[2]);

			fp_zero(n[0][1]);
			fp_copy(n[0][0], p->y);
			fp2_mul(n[0], n[0], r->z);
			fp2_zero(n[1]);
			fp2_zero(n[2]);

			fp6_copy(l[0], n);
			fp6_copy(l[1], d);
		}
	}
	CATCH_ANY {
		THROW(ERR_CAUGHT);
	}
	FINALLY {
		fp2_free(slope);
		ep2_free(t);
	}
}

/**
 * Doubles a prime elliptic curve point and evaluates the corresponding line
 * function at another elliptic curve point.
 * 
 * @param[out] l			- the result of the evaluation.
 * @param[out] r			- the result, in Jacobian coordinates.
 * @param[in] q				- the point to double, in Jacobian coordinates.
 * @param[in] p				- the point where the line function will be
 * 							evaluated, in Affine coordinates.
 */
void rate_dbl(fp12_t l, ep2_t r, ep2_t q, ep_t p) {
	fp2_t s;
	fp2_t e;
	ep2_t t;

	fp2_null(s);
	fp2_null(e);
	ep2_null(t);

	TRY {
		fp2_new(s);
		fp2_new(e);
		ep2_new(t);
		ep2_copy(t, r);
		ep2_dbl_slp(r, s, e, r);

		if (ep2_is_infty(r)) {
			fp12_zero(l);
			fp_set_dig(l[0][0][0], 1);
		} else {
			fp6_t n, d;

			fp6_new(d);
			fp6_new(n);

			fp2_sqr(d[2], t->z);
			fp2_mul(d[0], d[2], s);
			fp_mul(d[0][0], d[0][0], p->x);
			fp_mul(d[0][1], d[0][1], p->x);
			fp2_neg(d[0], d[0]);
			fp2_mul(d[1], s, t->x);
			fp2_sub(d[1], d[1], e);

			fp2_mul(n[0], r->z, d[2]);
			fp_mul(n[0][0], n[0][0], p->y);
			fp_mul(n[0][1], n[0][1], p->y);
			fp2_zero(d[2]);
			fp2_zero(n[1]);
			fp2_zero(n[2]);

			fp6_copy(l[0], n);
			fp6_copy(l[1], d);
		}
	}
	CATCH_ANY {
		THROW(ERR_CAUGHT);
	}
	FINALLY {
		fp2_free(s);
		fp2_free(e);
		ep2_free(t);
	}
}

/**
 * Compute the Miller loop for Ate variants over the bits of r.
 * 
 * @param[out] res			- the result.
 * @param[out] t			- the point rQ.
 * @param[in] q				- the first point of the pairing, in G_2.
 * @param[in] r				- the length of the loop.
 * @param[in] p				- the second point of the pairing, in G_1.
 */
void rate_miller(fp12_t res, ep2_t t, ep2_t q, bn_t r, ep_t p) {
	fp12_t tmp;
	unsigned int i;

	fp12_null(tmp);

	TRY {
		fp12_new(tmp);

		fp12_zero(res);
		fp_set_dig(res[0][0][0], 1);
		ep2_copy(t, q);

		for (i = bn_bits(r) - 1; i > 0; i--) {
			rate_dbl(tmp, t, t, p);
			fp12_sqr(res, res);
			fp12_mul_dxs(res, res, tmp);

			if (bn_test_bit(r, i - 1)) {
				rate_add(tmp, t, q, p);
				fp12_mul_dxs(res, res, tmp);
			}
		}
	}
	CATCH_ANY {
		THROW(ERR_CAUGHT);
	}
	FINALLY {
		fp12_free(tmp);
	}
}

/**
 * Compute the additional multiplication required by the R-Ate pairing.
 * 
 * @param[in,out] res		- the result.
 * @param[in] t				- the elliptic point produced by the Miller loop.
 * @param[in] q				- the first point of the pairing, in G_2. 
 * @param[in] p				- the second point of the pairing, in G_1.
 */
void rate_mult(fp12_t res, ep2_t t, ep2_t q, ep_t p) {
	ep2_t q1, r1q;
	fp12_t tmp1;
	fp12_t tmp2;

	fp12_null(tmp1);
	fp12_null(tmp2);
	ep2_null(q1);
	ep2_null(r1q);

	TRY {
		ep2_new(q1);
		ep2_new(r1q);
		fp12_new(tmp1);
		fp12_new(tmp2);

		ep2_copy(r1q, t);

		rate_add(tmp1, r1q, q, p);
		fp12_mul_dxs(tmp2, res, tmp1);
		fp12_frb(tmp2, tmp2);
		fp12_mul(res, res, tmp2);

		r1q->norm = 0;
		ep2_norm(r1q, r1q);

		ep2_frb(q1, r1q);

		ep2_copy(r1q, t);

		rate_add(tmp1, r1q, q1, p);
		fp12_mul_dxs(res, res, tmp1);
	} CATCH_ANY {
		THROW(ERR_CAUGHT);
	} FINALLY {
		fp12_free(tmp1);
		fp12_free(tmp2);
		ep2_free(q1);
		ep2_free(r1q);
	}
}

/**
 * Compute the final exponentiation of the rate pairing in a BN curve.
 * 
 * @param[in,out] m			- the result.
 * @param[in] x				- the parameter used to generate the curve.
 */
void rate_exp(fp12_t m, bn_t x) {
	fp12_t v0;
	fp12_t v1;
	fp12_t v2;
	fp12_t v3;

	fp12_null(v0);
	fp12_null(v1);
	fp12_null(v2);
	fp12_null(v3);

	TRY {
		fp12_new(v0);
		fp12_new(v1);
		fp12_new(v2);
		fp12_new(v3);

		/* First, compute m^(p^6 - 1). */
		/* tmp = m^{-1}. */
		fp12_inv(v0, m);
		/* m' = m^(p^6). */
		fp12_inv_uni(m, m);
		/* m' = m^(p^6 - 1). */
		fp12_mul(m, m, v0);

		/* Second, compute m^(p^2 + 1). */
		/* t = m^(p^2). */
		fp12_frb(v0, m);
		fp12_frb(v0, v0);
		/* m' = m^(p^2 + 1). */
		fp12_mul(m, m, v0);

		/* Third, compute m^((p^4 - p^2 + 1) / r). */
		/* From here on we work with x' = -x, therefore if x is positive
		 * we need inversions. */
		if (bn_sign(x) == BN_POS) {
			/* TODO: these inversions are probably just conjugations, test. */
			fp12_inv(v3, m);
			fp12_exp_uni(v0, v3, x);
			fp12_inv(v3, v0);
			fp12_exp_uni(v1, v3, x);
			fp12_inv(v3, v1);
			fp12_exp_uni(v2, v3, x);
		} else {
			fp12_exp_uni(v0, m, x);
			fp12_exp_uni(v1, v0, x);
			fp12_exp_uni(v2, v1, x);
		}

		fp12_frb(v3, v2);
		fp12_mul(v2, v2, v3);
		fp12_sqr_uni(v2, v2);
		fp12_frb(v3, v1);
		fp12_inv_uni(v3, v3);
		fp12_mul(v3, v3, v0);
		fp12_mul(v2, v2, v3);
		fp12_frb(v0, v0);
		fp12_inv_uni(v3, v1);
		fp12_mul(v2, v2, v3);
		fp12_mul(v0, v0, v3);
		fp12_frb(v1, v1);
		fp12_frb(v1, v1);
		fp12_mul(v0, v0, v2);
		fp12_mul(v2, v2, v1);
		fp12_sqr_uni(v0, v0);
		fp12_mul(v0, v0, v2);
		fp12_sqr_uni(v0, v0);
		fp12_inv_uni(v1, m);
		fp12_mul(v2, v0, v1);
		fp12_frb(v1, m);
		fp12_frb(v1, v1);
		fp12_frb(v3, v1);
		fp12_mul(v1, v1, v3);
		fp12_frb(v3, m);
		fp12_mul(v1, v1, v3);
		fp12_mul(v0, v0, v1);
		fp12_sqr_uni(v2, v2);
		fp12_mul(m, v2, v0);
	}
	CATCH_ANY {
		THROW(ERR_CAUGHT);
	}
	FINALLY {
		fp12_free(v0);
		fp12_free(v1);
		fp12_free(v2);
		fp12_free(v3);
	}
}

/*============================================================================*/
/* Public definitions                                                         */
/*============================================================================*/

void pp_map_rate(fp12_t r, ep2_t q, ep_t p) {
	ep2_t t;
	bn_t a, x;

	ep2_null(t);
	bn_null(a);
	bn_null(x);

	TRY {
		ep2_new(t);
		bn_new(a);
		bn_new(x);

		switch (fp_param_get()) {
			case BNN_256:
				/* x = -4080000000000001. */
				bn_set_2b(x, 62);
				bn_set_2b(a, 55);
				bn_add(x, x, a);
				bn_add_dig(x, x, 1);
				bn_neg(x, x);
				break;
			case BNP_256:
				/* x = 6000000000001F2D. */
				bn_set_2b(x, 62);
				bn_set_2b(a, 61);
				bn_add(x, x, a);
				bn_set_dig(a, 0x1F);
				bn_lsh(a, a, 8);
				bn_add(x, x, a);
				bn_add_dig(x, x, 0x2D);
				break;
		}

		bn_mul_dig(a, x, 6);
		bn_add_dig(a, a, 2);
		if (bn_sign(x) == BN_NEG) {
			bn_neg(a, a);
		}

		/* r = f_{r,Q}(P). */
		rate_miller(r, t, q, a, p);

		if (bn_sign(x) == BN_NEG) {
			/* Since f_{-r,Q}(P) = 1/f_{r,Q}(P), we must invert the result. */
			fp12_inv(r, r);
			ep2_neg(t, t);
		}

		rate_mult(r, t, q, p);

		rate_exp(r, x);

	}
	CATCH_ANY {
		THROW(ERR_CAUGHT);
	}
	FINALLY {
		ep2_free(t);
		bn_free(a);
		bn_free(x);
	}
}
